# Ritual
Decentralized AI inference and crypto infrastructure.